# ANPR_ir > 2024-08-19 10:33am
https://universe.roboflow.com/detection-rly2f/anpr_ir-wmd8a

Provided by a Roboflow user
License: CC BY 4.0

